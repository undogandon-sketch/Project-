from __future__ import annotations

import json
import random
import re

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST

from .config import ACTIVE_VARIANT

# ---------------------------------------------------------------------------
# Единственный метод API активного чата:
#   POST /api/chat/send/
#   body: {"message": "текст пользователя"}
#   response 200: {"reply": "ответное сообщение"}
#   response 400: {"error": "описание ошибки"}
#
# Демо-робот «Робот-Учёный» (доступен при каждом запуске):
#   страница  — GET /demo/
#   метод API — POST /api/chat/send_demo/
#   логика    — build_reply_demo (перенесена без изменений, суффикс _demo)
# ---------------------------------------------------------------------------


def _parse_message(request):
    """Разбирает JSON-тело запроса. Возвращает (message, error_response)."""
    try:
        data = json.loads(request.body or b'{}')
    except json.JSONDecodeError:
        error = JsonResponse(
            {'error': 'Тело запроса должно быть валидным JSON'}, status=400
        )
        return None, error

    message = str(data.get('message') or '').strip()
    if not message:
        error = JsonResponse({'error': 'Сообщение не может быть пустым'}, status=400)
        return None, error
    return message, None


# ===========================================================================
# ДЕМО: «Робот-Учёный» (логика НЕ менялась, переименована с суффиксом _demo)
# ===========================================================================
def build_reply_demo(message: str) -> str:
    """Формирует ответное сообщение бота (учебная демо-заглушка)."""
    text = message.strip().lower()

    greetings = ('привет', 'здравствуй', 'добрый день', 'hello', 'hi', 'салют')
    if any(word in text for word in greetings):
        return (
            'Привет-привет! 👋 Я Робот-Учёный, твой учебный напарник. '
            'Спрашивай про математику, науку, космос или динозавров — '
            'скучно не будет! 🚀'
        )

    if any(word in text for word in ('пример', 'задач', 'матем', 'сложить', 'умнож')):
        return (
            'Математика — это весело! 🧮 Вот тебе хитрость: 12 × 12 = 144, '
            '15 × 15 = 225, а 25 × 25 = 625. Заметил(а) закономерность? '
            'Это «квадраты чисел»! Попроси меня придумать тебе пример посложнее. 😉'
        )

    if 'динозавр' in text:
        return (
            'Динозавры — супертема! 🦖 Тираннозавр весил как 4 современные машины, '
            'а самый маленький динозаврик был размером с курицу! Хочешь узнать, '
            'почему они вымерли? Задай вопрос «Почему вымерли динозавры?» 🌋'
        )

    if any(word in text for word in ('физик', 'гравит', 'сила тяжест', 'небо голуб', 'молн')):
        return (
            'Отличный научный вопрос! ✨ Знаешь, почему небо голубое? '
            'Солнечный свет состоит из всех цветов, а голубой рассеивается '
            'в атмосфере лучше всех — поэтому мы видим именно его! Попробуй '
            'представить атмосферу как гигантское голубое светоотражающее зеркало. 🌈'
        )

    if any(word in text for word in ('космос', 'планет', 'звезд', 'лун')):
        return (
            'Космос — бесконечное приключение! 🪐 Если бы ты прыгнул(а) на Луне, '
            'то взлетел(а) бы в 6 раз выше, чем на Земле. А на Юпитере один день '
            'длится всего 10 часов! Узнать что-нибудь ещё о планетах? 🌍'
        )

    if any(word in text for word in ('?', 'как', 'почему', 'что', 'когда', 'где')):
        return (
            'Интересный вопрос! 🧠 Сначала подумай сам(а): что ты уже знаешь об '
            'этом? Потом мы проверим твою гипотезу вместе — учёные именно так и '
            'делают! 🔬 Расскажи, что думаешь?'
        )

    return random.choice([
        'Я тебя понял(а)! 😄 А теперь попробуй превратить эту мысль в вопрос — '
        'например, «Почему...?» или «Как это работает?». Так учёные добывают знания!',
        'Ого, интересная мысль! ✨ Давай заглянем в «копилку знаний»: о чём бы '
        'ты хотел(а) узнать подробнее — математика, природа или космос?',
        'Супер! 🎉 За такой настрой тебе +25 XP! А знаешь ли ты, что любое '
        'явление можно проверить экспериментом? Попроси меня помочь придумать опыт!',
        'Круто! 🤩 Я записал(а) это в свою «таблицу знаний». Задавай следующий '
        'вопрос — мы вместе разберёмся в чём угодно!',
    ])


# ===========================================================================
# НОВЫЕ ВАРИАНТЫ ОФОРМЛЕНИЯ
# build_reply_* оставлены заглушкой «ПРИВЕТ» — код внутри НЕ реализован.
# ===========================================================================
def build_reply_magic(message: str) -> str:
    # TODO(магический помощник): волшебник в академии магии — задания,
    # загадки, проверка ответов, очки опыта и уровни.
    return 'ПРИВЕТ'


def build_reply_ship(message: str) -> str:
    # TODO(бортовой компьютер): состояние корабля, двигатели, топливо,
    # исследование планет, случайные события, аварии.
    return 'ПРИВЕТ'


# ===========================================================================
# ДЕТЕКТИВ: «Шерлок Байт» — расследование кражи в музее
# Состояние дела хранится в памяти процесса (один игрок на сервер).
# Преступник выбирается случайно при каждом новом деле.
# ===========================================================================
_DETECTIVE_BASE = {
    'boris': {
        'name': 'Сторож Борис', 'words': ('борис', 'сторож'),
        'smell': 'машинное масло', 'shoes': 'тяжёлые рабочие ботинки',
        'item': 'связка ключей',
        'alibi': 'Всю ночь обходил двор с фонарём. Про окно в зале ничего не знаю — ветер был сильный.',
    },
    'lena': {
        'name': 'Гид Лена', 'words': ('лен', 'гид'),
        'smell': 'лаванда', 'shoes': 'туфли на каблуках',
        'item': 'красный шарф',
        'alibi': 'Я готовила завтрашнюю экскурсию в своём кабинете. Скарабея я в последний раз видела вечером.',
    },
    'igor': {
        'name': 'Реставратор Игорь', 'words': ('игор', 'реставратор'),
        'smell': 'ваниль', 'shoes': 'белые кроссовки',
        'item': 'блокнот',
        'alibi': 'Я работал в мастерской над старой вазой. Выходил только за чаем, честное слово!',
    },
}

_DETECTIVE_ITEM_CLUE = {
    'связка ключей': 'на оконной раме висит металлический брелок — такие бывают на связках ключей',
    'красный шарф': 'за шпингалет окна зацепилась красная шерстяная нитка',
    'блокнот': 'на подоконнике лежит листок, вырванный из блокнота',
}

# место -> (слова-триггеры, тип улики)
_DETECTIVE_PLACES = {
    'витрина': (('витрин', 'стекл', 'скарабей'), 'smell'),
    'коридор': (('коридор', 'пол', 'след'), 'shoes'),
    'окно': (('окн', 'рам', 'подоконник'), 'item'),
}

_DETECTIVE_HELP = (
    'Команды детектива 🔍:\n'
    '• «дело» — напомнить, что случилось\n'
    '• «осмотреть витрину / коридор / окно» — искать улики\n'
    '• «допросить Бориса / Лену / Игоря» — выслушать подозреваемого\n'
    '• «улики» — мой блокнот с находками\n'
    '• «обвинить <имя>» — назвать преступника (у тебя 2 попытки!)\n'
    '• «новое дело» — начать заново'
)

_detective_state: dict = {}


def _detective_new_case() -> dict:
    suspects = {k: dict(v) for k, v in _DETECTIVE_BASE.items()}
    culprit = random.choice(list(suspects))
    others = [k for k in suspects if k != culprit]
    random.shuffle(others)
    # «ложные следы»: у невиновных совпадает по одной примете
    suspects[others[0]]['smell'] = suspects[culprit]['smell']
    suspects[others[1]]['shoes'] = suspects[culprit]['shoes']
    return {
        'culprit': culprit, 'suspects': suspects,
        'clues': {}, 'wrong': 0, 'over': False, 'started': False,
    }


def _detective_intro() -> str:
    return (
        'Добро пожаловать, юный детектив! 🕵️ Я — Шерлок Байт, твой помощник.\n\n'
        '📁 ДЕЛО №1: «Исчезнувший Золотой Скарабей». Этой ночью из городского '
        'музея пропал древний артефакт. Преступник влез через окно, а подозреваемых трое: '
        'сторож Борис, гид Лена и реставратор Игорь.\n\n'
        'Осмотри место преступления, допроси подозреваемых и сравни приметы. '
        'Виновен только один!\n\n' + _DETECTIVE_HELP
    )


def _detective_describe(s: dict) -> str:
    return f'пахнет — {s["smell"]}; обувь — {s["shoes"]}; при себе — {s["item"]}'


def _detective_tokens(text: str):
    return re.findall(r'\w+', text)


def _detective_find_suspect(tokens):
    for key, s in _DETECTIVE_BASE.items():
        if any(t.startswith(w) for t in tokens for w in s['words']):
            return key
    return None


def _detective_find_place(tokens):
    for place, (words, _kind) in _DETECTIVE_PLACES.items():
        if any(t.startswith(w) for t in tokens for w in words):
            return place
    return None


def _detective_clue_text(case: dict, kind: str) -> str:
    c = case['suspects'][case['culprit']]
    if kind == 'smell':
        return f'в воздухе у витрины витает запах: {c["smell"]}'
    if kind == 'shoes':
        return f'на полу чёткие следы: {c["shoes"]}'
    return _DETECTIVE_ITEM_CLUE[c['item']]


def _detective_notes(case: dict) -> str:
    if not case['clues']:
        return 'В моём блокноте пока пусто 📓. Осмотри витрину, коридор и окно!'
    lines = [f'• {place.capitalize()}: {_detective_clue_text(case, kind)}'
             for place, kind in ((p, _DETECTIVE_PLACES[p][1]) for p in case['clues'])]
    left = len(_DETECTIVE_PLACES) - len(case['clues'])
    tail = f'\nОсталось мест для осмотра: {left}.' if left else '\nВсе места осмотрены — пора делать выводы! 🧠'
    return '📓 Улики:\n' + '\n'.join(lines) + tail


def _detective_accuse(case: dict, key: str) -> str:
    if len(case['clues']) < 2:
        return 'Погоди! ✋ Без улик обвинение не примут. Найди хотя бы две — осмотри место преступления.'

    suspect = case['suspects'][key]
    culprit = case['suspects'][case['culprit']]

    if key == case['culprit']:
        case['over'] = True
        xp = max(40, 100 - 30 * case['wrong'])
        return (
            f'🎉 ДЕЛО РАСКРЫТО! Это {suspect["name"]}! Совпали все приметы: '
            f'{_detective_describe(suspect)}.\n'
            f'Золотой Скарабей возвращён в музей, а ты получаешь +{xp} XP! 🏆\n'
            'Напиши «новое дело», если хочешь расследовать снова.'
        )

    labels = {'smell': 'запах', 'shoes': 'обувь', 'item': 'предмет'}
    mismatches = [labels[k] for k in case['clues'].values() if suspect[k] != culprit[k]]
    case['wrong'] += 1

    if case['wrong'] >= 2:
        case['over'] = True
        return (
            f'❌ И снова мимо. Настоящий преступник — {culprit["name"]}: '
            f'{_detective_describe(culprit)}. Не расстраивайся, даже великие детективы ошибались! '
            'Напиши «новое дело» — и попробуем ещё раз. 💪'
        )

    if mismatches:
        hint = f'{suspect["name"]} не подходит — не совпадает: {", ".join(mismatches)}.'
    else:
        hint = 'Найденные улики подходят и ему, но их пока маловато, чтобы быть уверенным.'
    return f'❌ Не тот! {hint} Осталась 1 попытка — думай внимательно! 🤔'


def build_reply_detective(message: str) -> str:
    """Детективный бот «Шерлок Байт»: улики, допросы, обвинение."""
    global _detective_state
    text = message.strip().lower()
    tokens = _detective_tokens(text)

    if not _detective_state or 'новое дело' in text or 'заново' in text:
        _detective_state = _detective_new_case()
        _detective_state['started'] = True
        return _detective_intro()

    case = _detective_state

    if case['over']:
        return 'Это дело уже закрыто 📁. Напиши «новое дело», чтобы взяться за следующее!'

    if not case['started']:
        case['started'] = True
        return _detective_intro()

    if any(w in text for w in ('помощ', 'help', 'команд', 'что делать')):
        return _DETECTIVE_HELP

    suspect_key = _detective_find_suspect(tokens)

    if any(w in text for w in ('обвин', 'виновн', 'арест', 'версия', 'это он', 'это она')):
        if not suspect_key:
            return 'Кого ты подозреваешь? Назови имя: Борис, Лена или Игорь. 🧐'
        return _detective_accuse(case, suspect_key)

    if any(w in text for w in ('улик', 'блокнот', 'заметк')):
        return _detective_notes(case)

    if any(w in text for w in ('допрос', 'спрос', 'поговор', 'алиби', 'подозреваем', 'свидетел')) or suspect_key:
        if not suspect_key:
            names = ', '.join(s['name'] for s in _DETECTIVE_BASE.values())
            return f'Подозреваемые: {names}. Кого допросим? 🗣️'
        s = case['suspects'][suspect_key]
        return (
            f'🗣️ {s["name"]} говорит: «{s["alibi"]}»\n'
            f'Я присмотрелся: {_detective_describe(s)}. Запиши и сравни с уликами! 📝'
        )

    place = _detective_find_place(tokens)
    if place or any(w in text for w in ('осмотр', 'исслед', 'искать', 'ищи')):
        if not place:
            return 'Где будем искать? Осмотри витрину, коридор или окно. 🔎'
        case['clues'][place] = _DETECTIVE_PLACES[place][1]
        clue = _detective_clue_text(case, _DETECTIVE_PLACES[place][1])
        return f'🔎 Осматриваем место «{place}»… Улика найдена: {clue}! Записываю в блокнот.'

    if any(w in text for w in ('дело', 'что случилось', 'задани')):
        return (
            'Из музея пропал Золотой Скарабей 🪲. Подозреваемые: сторож Борис, гид Лена '
            'и реставратор Игорь. Найди улики и назови виновного! '
            f'Улик найдено: {len(case["clues"])} из {len(_DETECTIVE_PLACES)}.'
        )

    return random.choice([
        'Интересная мысль! 🧐 Но детективу нужны факты. Попробуй «осмотреть окно» или «допросить Лену».',
        'Хм… 🤔 Не совсем понял. Напиши «помощь», и я напомню, что умеет настоящий сыщик!',
        'Каждая деталь важна! 🔍 Загляни в «улики» или допроси кого-нибудь из подозреваемых.',
    ])



def build_reply_trader(message: str) -> str:
    # TODO(умный торговец): ассортимент и цены, покупка/продажа,
    # баланс игрока, случайные скидки, подсчёт покупки.
    return 'ПРИВЕТ'


def build_reply_survival(message: str) -> str:
    # TODO(бот выживания): запасы еды и воды, исследование острова,
    # случайные события, постройка убежища, проверка «выживет ли игрок».
    return 'ПРИВЕТ'


def build_reply_dungeon(message: str) -> str:
    # TODO(хранитель подземелья): генерация комнат и событий, сражение/
    # исследование/отдых, здоровье и инвентарь, награды, память приключения.
    return 'ПРИВЕТ'


# Диспетчер: активный вариант (config.json) -> его build_reply_*
REPLY_BUILDERS = {
    'robot': build_reply_demo,
    'magic': build_reply_magic,
    'ship': build_reply_ship,
    'detective': build_reply_detective,
    'trader': build_reply_trader,
    'survival': build_reply_survival,
    'dungeon': build_reply_dungeon,
}


def chat_page(request):
    """Страница активного (настроенного в config.json) варианта чата."""
    return render(request, f'chat/{ACTIVE_VARIANT}.html')


def chat_page_demo(request):
    """Демо-страница «Робот-Учёный», доступна всегда по /demo/."""
    return render(request, 'chat/robot.html')


@require_POST
def api_chat_send(request):
    """POST /api/chat/send/ — метод активного варианта чата."""
    message, error = _parse_message(request)
    if error:
        return error
    builder = REPLY_BUILDERS.get(ACTIVE_VARIANT, build_reply_demo)
    return JsonResponse({'reply': builder(message)})


@require_POST
def api_chat_send_demo(request):
    """POST /api/chat/send_demo/ — метод демо-робота (всегда один и тот же)."""
    message, error = _parse_message(request)
    if error:
        return error
    return JsonResponse({'reply': build_reply_demo(message)})